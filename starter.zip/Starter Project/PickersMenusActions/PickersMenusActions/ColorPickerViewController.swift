//
//  ColorPickerViewController.swift
//  PickersMenusActions
//
//  Created by Gabriel Theodoropoulos.
//

import UIKit

class ColorPickerViewController: UIViewController {

    @IBOutlet weak var colorSampleView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func pickColor(_ sender: Any) {
        
    }

}
